create definer = root@localhost trigger new_leave
    after insert
    on work_leaves
    for each row
BEGIN
UPDATE employees SET avaiable_days=avaiable_days-new.days WHERE id=new.employee_id;
END;

