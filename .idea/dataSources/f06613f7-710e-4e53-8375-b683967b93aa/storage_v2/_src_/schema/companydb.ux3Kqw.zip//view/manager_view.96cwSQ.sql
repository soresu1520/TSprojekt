create view manager_view as
select `e`.`id`                                       AS `employee_id`,
       `w`.`id`                                       AS `leave_id`,
       concat(`e`.`first_name`, ' ', `e`.`last_name`) AS `employee_name`,
       `e`.`eposition`                                AS `eposition`,
       `e`.`leave_days`                               AS `leave_days`,
       `e`.`avaiable_days`                            AS `avaiable_days`,
       `w`.`start_date`                               AS `start_date`,
       `w`.`end_date`                                 AS `end_date`,
       `w`.`days`                                     AS `days`,
       `w`.`leave_type`                               AS `leave_type`,
       `w`.`leave_status`                             AS `leave_status`
from (`companydb`.`work_leaves` `w`
         join `companydb`.`employees` `e` on ((`w`.`employee_id` = `e`.`id`)));

