create definer = root@localhost trigger not_accepted
    after delete
    on work_leaves
    for each row
BEGIN 
INSERT INTO leaves_archive(id, start_date, end_date, days, leave_type, employee_id)
VALUES(old.id, old.start_date, old.end_date, old.days, old.leave_type, old.employee_id);

UPDATE employees SET avaiable_days=avaiable_days+old.days WHERE id=old.employee_id;
END;

